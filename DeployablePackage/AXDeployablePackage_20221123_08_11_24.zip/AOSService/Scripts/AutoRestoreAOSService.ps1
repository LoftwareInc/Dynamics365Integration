﻿<#
.SYNOPSIS
    Restore the AOS service files from a backup.

.DESCRIPTION

    Copyright © 2019 Microsoft. All rights reserved.
#>
[CmdletBinding()]
param
(
    [Parameter(Mandatory = $false, HelpMessage = "The path to the directory in which to write log files.")]
    [string]$LogDir
)

function CleanupDeltaDBsyncReportDeployment([string]$metadataPackagePath)
{
    $MetadataParentPath = Split-Path -Path $metadataPackagePath -Parent
    $DeltaSyncFolder = Join-Path -Path $MetadataParentPath -ChildPath "DeltaSync"

    if (Test-Path -Path $DeltaSyncFolder)
    {
        Get-ChildItem -Path $DeltaSyncFolder | Remove-Item -Force -Recurse
    }
}

function GenerateSymLinkNgen([string]$webroot, [string]$metadataPackagePath)
{
    $webconfig = Join-Path -Path $webroot -ChildPath "web.config"
    [System.Xml.XmlDocument]$xd = New-Object System.Xml.XmlDocument
    $xd.Load($webconfig)
    $ns = New-Object System.Xml.XmlNamespaceManager($xd.NameTable)
    $ns.AddNamespace("ns", $xd.DocumentElement.NamespaceURI)

    $key = "UseLazyTypeLoader"
    $value = "false"
    $existingNode = $xd.SelectSingleNode("//ns:add[@key='$key']", $ns)

    if ($existingNode)
    {
        $existingValue = $existingNode.GetAttribute("value")
        if ($existingValue -eq $value)
        {
            Write-ServicingLog "Updating Symlink and Ngen Assemblies"
            $SymLinkNgenLog = Join-Path -Path $PSScriptRoot -ChildPath "update_SymLink_NgenAssemblies.log"
            $argumentList = '–webroot:"$webroot" –packagedir:"$metadataPackagePath" –log:"$($SymLinkNgenLog)"'
            Invoke-Expression "$metadataPackagePath\bin\CreateSymLinkAndNgenAssemblies.ps1 $argumentList"
        }
    }
}

$ErrorActionPreference = "Stop"
Import-Module WebAdministration
Import-Module "$PSScriptRoot\CommonRollbackUtilities.psm1" -DisableNameChecking
Import-Module "$PSScriptRoot\AosEnvironmentUtilities.psm1" -Force -DisableNameChecking

# Initialize exit code.
[int]$ExitCode = 0

# Initialize the log file to use with Write-ServicingLog.
Set-ServicingLog -LogDir $LogDir -LogFileName "AosService-Restore_$([DateTime]::UtcNow.ToString("yyyyMMddHHmmss")).log"

try
{
    Write-ServicingLog "Starting AOS restore..."

    # $RunbookBackupFolder and $PSScriptRoot variables are populated directly from runbook.
    $BackupFolder = $RunbookBackupFolder

    if ([string]::IsNullOrEmpty($BackupFolder))
    {
        $BackupFolder = Join-Path -Path $PSScriptRoot -ChildPath "ManualAosServiceBackup"
    }

    # Determine if this is a developer/demo machine.
    $DeveloperBox = Get-DevToolsInstalled

    Write-ServicingLog "Backup folder: $($BackupFolder)"

    $webrootBackupFolder = Join-Path -Path $BackupFolder -ChildPath "webroot"
    $packageBackupFolder = Join-Path -Path $BackupFolder -ChildPath "packages"
    $webrootBackupFilePath = Join-Path -Path $webrootBackupFolder -ChildPath "webroot.zip"
    $packageBackupFilePath = Join-Path -Path $packageBackupFolder -ChildPath "packages.zip"

    if (!(Test-Path -Path $webrootBackupFilePath))
    {
        # This backup is not created on machines with developer tools installed, so it should not
        # be considered an error if it does not exist. See AutoBackupAosService.ps1.
        if ($DeveloperBox)
        {
            Write-ServicingLog "Skipping restore as backup file for AOS webroot was not found at $($webrootBackupFilePath)."
            Write-ServicingLog "AOS restore script completed with exit code: $($ExitCode)."
            exit $ExitCode
        }
        else
        {
            throw "Failed to find the backup file for AOS webroot at $($webrootBackupFilePath), restore aborted."
        }
    }

    if (!(Test-Path -Path $packageBackupFilePath))
    {
        # This backup is not created on machines with developer tools installed, so it should not
        # be considered an error if it does not exist. See AutoBackupAosService.ps1.
        if ($DeveloperBox)
        {
            Write-ServicingLog "Skipping restore as backup file for AOS package was not found at $($packageBackupFilePath)."
            Write-ServicingLog "AOS restore script completed with exit code: $($ExitCode)."
            exit $ExitCode
        }
        else
        {
            throw "Failed to find the backup file for AOS package at $($packageBackupFilePath), restore aborted."
        }
    }

    # Ensure AOS service is stopped.
    # This is a mitigation in case the machine was rebooted or the AOS service started while deployable package.
    Write-ServicingLog "Calling script to stop the AOS..."
    & "$PSScriptRoot\AutoStopAOS.ps1"

    # Restore AOS webroot.
    $webroot = Get-AosWebSitePhysicalPath
    $webrootBackupJunkFolder = Join-Path -Path $webrootBackupFolder -ChildPath "junk"
    $exclude = "*.config"

    Write-ServicingLog "Restoring AOS webroot files to $($webroot)..."

    Write-ServicingLog "Removing existing AOS webroot symlinks..." -Vrb
    Copy-SymbolicLinks -SourcePath $webroot -DestinationPath $webrootBackupJunkFolder -Move

    Write-ServicingLog "Removing existing AOS webroot files (Excluding: $exclude)..." -Vrb
    Get-ChildItem -Path $webroot -Recurse | Remove-Item -Force -Recurse -Exclude $exclude

    Write-ServicingLog "Restoring AOS webroot files from $($webrootBackupFilePath)..." -Vrb
    Unpack-ZipFiles -sourceFile:$webrootBackupFilePath -destFolder:$webroot

    # Restore AOS packages.
    $packagePath = Get-AOSPackageDirectory
    $packageBackupJunkFolder = Join-Path -Path $packageBackupFolder -ChildPath "junk"
    $exclude = "*.bak"

    Write-ServicingLog "Restoring AOS packages to $($packagePath)..."

    Write-ServicingLog "Removing existing AOS packages symlinks..." -Vrb
    Copy-SymbolicLinks -SourcePath $packagePath -DestinationPath $packageBackupJunkFolder -Move

    Write-ServicingLog "Removing existing AOS packages (Excluding: $exclude)..." -Vrb
    Get-ChildItem -Path $packagePath -Recurse | Remove-Item -Force -Recurse -Exclude $exclude

    Write-ServicingLog "Restoring AOS packages from $($packageBackupFilePath)..." -Vrb
    Unpack-ZipFiles -sourceFile:$packageBackupFilePath -destFolder:$packagePath

    # Restore symlinks from backup.
    $packageBackupSymlinkFolder = Join-Path -Path $packageBackupFolder -ChildPath "symlink"
    $webrootBackupSymlinkFolder = Join-Path -Path $webrootBackupFolder -ChildPath "symlink"

    Write-ServicingLog "Restoring AOS packages symlinks..." -Vrb
    Copy-SymbolicLinks -SourcePath $packageBackupSymlinkFolder -DestinationPath $packagePath

    Write-ServicingLog "Restoring AOS webroot symlinks..." -Vrb
    Copy-SymbolicLinks -SourcePath $webrootBackupSymlinkFolder -DestinationPath $webroot

    # Cleanup.
    Write-ServicingLog "Cleaning up delta DbSync report deployment..."
    CleanupDeltaDBsyncReportDeployment -metadataPackagePath:$packagePath

    try
    {
        if (!$DeveloperBox)
        {
            if (Test-Path -Path "$PSScriptRoot\RemoveSymLinkAndNgenAssemblies.ps1")
            {
                Write-Output "Removing SymLink And NgenAssemblies..."
                Invoke-Expression "$PSScriptRoot\RemoveSymLinkAndNgenAssemblies.ps1"
                Write-Output "Removing SymLink And NgenAssemblies completed."
            }
        }
    }
    catch
    {
        Write-Output "Warning: Failed to remove SymLink And NgenAssemblies: $($_)"
        Write-Output "Generating SymLink And NgenAssemblies..."
        GenerateSymLinkNgen -webroot:$webroot -metadataPackagePath:$packagePath
        Write-Output "Generating SymLink And NgenAssemblies completed."
    }

    # Generate installation records.
    Write-ServicingLog "Generating installation records..."
    GenerateMetadataModuleInstallationInfo
}
catch
{
    # Ensure non-zero exit code if an exception is caught and no exit code set.
    if ($ExitCode -eq 0)
    {
        $ExitCode = 1024
    }

    $ErrorMessage = "Error during AOS restore: $($_)"

    Write-ServicingLog $ErrorMessage
    Write-ServicingLog $($_) -Vrb
    Write-ServicingLog "AOS restore script failed with exit code: $($ExitCode)."

    # Use throw to indicate error to AXUpdateInstaller.
    # In case of exceptions, the output is not captured, so only the error message and
    # log file contents will be available for diagnostics.
    throw "$($ErrorMessage) [Log: $(Get-ServicingLog)]"
}

Write-ServicingLog "AOS restore script completed with exit code: $($ExitCode)."
exit $ExitCode
# SIG # Begin signature block
# MIInnQYJKoZIhvcNAQcCoIInjjCCJ4oCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCD799pORimEHCLV
# IS6pcQUQOps6iWr/GvSm5tNvMHvr5qCCDYEwggX/MIID56ADAgECAhMzAAACzI61
# lqa90clOAAAAAALMMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjIwNTEyMjA0NjAxWhcNMjMwNTExMjA0NjAxWjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQCiTbHs68bADvNud97NzcdP0zh0mRr4VpDv68KobjQFybVAuVgiINf9aG2zQtWK
# No6+2X2Ix65KGcBXuZyEi0oBUAAGnIe5O5q/Y0Ij0WwDyMWaVad2Te4r1Eic3HWH
# UfiiNjF0ETHKg3qa7DCyUqwsR9q5SaXuHlYCwM+m59Nl3jKnYnKLLfzhl13wImV9
# DF8N76ANkRyK6BYoc9I6hHF2MCTQYWbQ4fXgzKhgzj4zeabWgfu+ZJCiFLkogvc0
# RVb0x3DtyxMbl/3e45Eu+sn/x6EVwbJZVvtQYcmdGF1yAYht+JnNmWwAxL8MgHMz
# xEcoY1Q1JtstiY3+u3ulGMvhAgMBAAGjggF+MIIBejAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUiLhHjTKWzIqVIp+sM2rOHH11rfQw
# UAYDVR0RBEkwR6RFMEMxKTAnBgNVBAsTIE1pY3Jvc29mdCBPcGVyYXRpb25zIFB1
# ZXJ0byBSaWNvMRYwFAYDVQQFEw0yMzAwMTIrNDcwNTI5MB8GA1UdIwQYMBaAFEhu
# ZOVQBdOCqhc3NyK1bajKdQKVMFQGA1UdHwRNMEswSaBHoEWGQ2h0dHA6Ly93d3cu
# bWljcm9zb2Z0LmNvbS9wa2lvcHMvY3JsL01pY0NvZFNpZ1BDQTIwMTFfMjAxMS0w
# Ny0wOC5jcmwwYQYIKwYBBQUHAQEEVTBTMFEGCCsGAQUFBzAChkVodHRwOi8vd3d3
# Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NlcnRzL01pY0NvZFNpZ1BDQTIwMTFfMjAx
# MS0wNy0wOC5jcnQwDAYDVR0TAQH/BAIwADANBgkqhkiG9w0BAQsFAAOCAgEAeA8D
# sOAHS53MTIHYu8bbXrO6yQtRD6JfyMWeXaLu3Nc8PDnFc1efYq/F3MGx/aiwNbcs
# J2MU7BKNWTP5JQVBA2GNIeR3mScXqnOsv1XqXPvZeISDVWLaBQzceItdIwgo6B13
# vxlkkSYMvB0Dr3Yw7/W9U4Wk5K/RDOnIGvmKqKi3AwyxlV1mpefy729FKaWT7edB
# d3I4+hldMY8sdfDPjWRtJzjMjXZs41OUOwtHccPazjjC7KndzvZHx/0VWL8n0NT/
# 404vftnXKifMZkS4p2sB3oK+6kCcsyWsgS/3eYGw1Fe4MOnin1RhgrW1rHPODJTG
# AUOmW4wc3Q6KKr2zve7sMDZe9tfylonPwhk971rX8qGw6LkrGFv31IJeJSe/aUbG
# dUDPkbrABbVvPElgoj5eP3REqx5jdfkQw7tOdWkhn0jDUh2uQen9Atj3RkJyHuR0
# GUsJVMWFJdkIO/gFwzoOGlHNsmxvpANV86/1qgb1oZXdrURpzJp53MsDaBY/pxOc
# J0Cvg6uWs3kQWgKk5aBzvsX95BzdItHTpVMtVPW4q41XEvbFmUP1n6oL5rdNdrTM
# j/HXMRk1KCksax1Vxo3qv+13cCsZAaQNaIAvt5LvkshZkDZIP//0Hnq7NnWeYR3z
# 4oFiw9N2n3bb9baQWuWPswG0Dq9YT9kb+Cs4qIIwggd6MIIFYqADAgECAgphDpDS
# AAAAAAADMA0GCSqGSIb3DQEBCwUAMIGIMQswCQYDVQQGEwJVUzETMBEGA1UECBMK
# V2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0
# IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0aWZpY2F0
# ZSBBdXRob3JpdHkgMjAxMTAeFw0xMTA3MDgyMDU5MDlaFw0yNjA3MDgyMTA5MDla
# MH4xCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdS
# ZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMT
# H01pY3Jvc29mdCBDb2RlIFNpZ25pbmcgUENBIDIwMTEwggIiMA0GCSqGSIb3DQEB
# AQUAA4ICDwAwggIKAoICAQCr8PpyEBwurdhuqoIQTTS68rZYIZ9CGypr6VpQqrgG
# OBoESbp/wwwe3TdrxhLYC/A4wpkGsMg51QEUMULTiQ15ZId+lGAkbK+eSZzpaF7S
# 35tTsgosw6/ZqSuuegmv15ZZymAaBelmdugyUiYSL+erCFDPs0S3XdjELgN1q2jz
# y23zOlyhFvRGuuA4ZKxuZDV4pqBjDy3TQJP4494HDdVceaVJKecNvqATd76UPe/7
# 4ytaEB9NViiienLgEjq3SV7Y7e1DkYPZe7J7hhvZPrGMXeiJT4Qa8qEvWeSQOy2u
# M1jFtz7+MtOzAz2xsq+SOH7SnYAs9U5WkSE1JcM5bmR/U7qcD60ZI4TL9LoDho33
# X/DQUr+MlIe8wCF0JV8YKLbMJyg4JZg5SjbPfLGSrhwjp6lm7GEfauEoSZ1fiOIl
# XdMhSz5SxLVXPyQD8NF6Wy/VI+NwXQ9RRnez+ADhvKwCgl/bwBWzvRvUVUvnOaEP
# 6SNJvBi4RHxF5MHDcnrgcuck379GmcXvwhxX24ON7E1JMKerjt/sW5+v/N2wZuLB
# l4F77dbtS+dJKacTKKanfWeA5opieF+yL4TXV5xcv3coKPHtbcMojyyPQDdPweGF
# RInECUzF1KVDL3SV9274eCBYLBNdYJWaPk8zhNqwiBfenk70lrC8RqBsmNLg1oiM
# CwIDAQABo4IB7TCCAekwEAYJKwYBBAGCNxUBBAMCAQAwHQYDVR0OBBYEFEhuZOVQ
# BdOCqhc3NyK1bajKdQKVMBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMAsGA1Ud
# DwQEAwIBhjAPBgNVHRMBAf8EBTADAQH/MB8GA1UdIwQYMBaAFHItOgIxkEO5FAVO
# 4eqnxzHRI4k0MFoGA1UdHwRTMFEwT6BNoEuGSWh0dHA6Ly9jcmwubWljcm9zb2Z0
# LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcmwwXgYIKwYBBQUHAQEEUjBQME4GCCsGAQUFBzAChkJodHRwOi8vd3d3Lm1p
# Y3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcnQwgZ8GA1UdIASBlzCBlDCBkQYJKwYBBAGCNy4DMIGDMD8GCCsGAQUFBwIB
# FjNodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2RvY3MvcHJpbWFyeWNw
# cy5odG0wQAYIKwYBBQUHAgIwNB4yIB0ATABlAGcAYQBsAF8AcABvAGwAaQBjAHkA
# XwBzAHQAYQB0AGUAbQBlAG4AdAAuIB0wDQYJKoZIhvcNAQELBQADggIBAGfyhqWY
# 4FR5Gi7T2HRnIpsLlhHhY5KZQpZ90nkMkMFlXy4sPvjDctFtg/6+P+gKyju/R6mj
# 82nbY78iNaWXXWWEkH2LRlBV2AySfNIaSxzzPEKLUtCw/WvjPgcuKZvmPRul1LUd
# d5Q54ulkyUQ9eHoj8xN9ppB0g430yyYCRirCihC7pKkFDJvtaPpoLpWgKj8qa1hJ
# Yx8JaW5amJbkg/TAj/NGK978O9C9Ne9uJa7lryft0N3zDq+ZKJeYTQ49C/IIidYf
# wzIY4vDFLc5bnrRJOQrGCsLGra7lstnbFYhRRVg4MnEnGn+x9Cf43iw6IGmYslmJ
# aG5vp7d0w0AFBqYBKig+gj8TTWYLwLNN9eGPfxxvFX1Fp3blQCplo8NdUmKGwx1j
# NpeG39rz+PIWoZon4c2ll9DuXWNB41sHnIc+BncG0QaxdR8UvmFhtfDcxhsEvt9B
# xw4o7t5lL+yX9qFcltgA1qFGvVnzl6UJS0gQmYAf0AApxbGbpT9Fdx41xtKiop96
# eiL6SJUfq/tHI4D1nvi/a7dLl+LrdXga7Oo3mXkYS//WsyNodeav+vyL6wuA6mk7
# r/ww7QRMjt/fdW1jkT3RnVZOT7+AVyKheBEyIXrvQQqxP/uozKRdwaGIm1dxVk5I
# RcBCyZt2WwqASGv9eZ/BvW1taslScxMNelDNMYIZcjCCGW4CAQEwgZUwfjELMAkG
# A1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQx
# HjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEoMCYGA1UEAxMfTWljcm9z
# b2Z0IENvZGUgU2lnbmluZyBQQ0EgMjAxMQITMwAAAsyOtZamvdHJTgAAAAACzDAN
# BglghkgBZQMEAgEFAKCBrjAZBgkqhkiG9w0BCQMxDAYKKwYBBAGCNwIBBDAcBgor
# BgEEAYI3AgELMQ4wDAYKKwYBBAGCNwIBFTAvBgkqhkiG9w0BCQQxIgQg++PQXtrf
# o+3J5P0o3Io+rBTk6bShhbWrDQjnIFMtpQIwQgYKKwYBBAGCNwIBDDE0MDKgFIAS
# AE0AaQBjAHIAbwBzAG8AZgB0oRqAGGh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbTAN
# BgkqhkiG9w0BAQEFAASCAQCdknpNvuy4IZVMWw5liVXMohL0qT5QIWv/iP6f2s8j
# 4wjeoK1HBKvIauMnoielqj1G2qjQ3dF3P4Xfe1DYv5fBzLajBXBfjG+nUyzas5ZM
# UVQGuTPUnhl6SUCcr3nNh5drRQYOOt70zmI0EBR4TWJSoSx3kEV7PlHlgulEORGf
# c0/ER7opnc1gqfBsXepCfeKLuxoAewfYr0wrgHptr1jVLS903q74Y7A1ejDnZ1l4
# U63QX9N0SaUoxJhQ883IW/VMR52qkxTVswhEHu9WXqpjHilimhqONyMGNWxCbw8u
# G6+vhgWycWaRnKfKAgqbaCwMQscHG22OJS+w0AyzP2hXoYIW/DCCFvgGCisGAQQB
# gjcDAwExghboMIIW5AYJKoZIhvcNAQcCoIIW1TCCFtECAQMxDzANBglghkgBZQME
# AgEFADCCAU8GCyqGSIb3DQEJEAEEoIIBPgSCATowggE2AgEBBgorBgEEAYRZCgMB
# MDEwDQYJYIZIAWUDBAIBBQAEIBU6kcn7UhCCpBSxK4VbCzMO0nPcxnYkjbNCRHym
# Lxk2AgZjERpbJrwYETIwMjIwOTAzMjAyOTM0LjlaMASAAgH0oIHQpIHNMIHKMQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSUwIwYDVQQLExxNaWNy
# b3NvZnQgQW1lcmljYSBPcGVyYXRpb25zMSYwJAYDVQQLEx1UaGFsZXMgVFNTIEVT
# TjozQkJELUUzMzgtRTlBMTElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAg
# U2VydmljZaCCEVUwggcMMIIE9KADAgECAhMzAAABnf6J5fl7u0zAAAEAAAGdMA0G
# CSqGSIb3DQEBCwUAMHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9u
# MRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRp
# b24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwMB4XDTIx
# MTIwMjE5MDUxOVoXDTIzMDIyODE5MDUxOVowgcoxCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xJTAjBgNVBAsTHE1pY3Jvc29mdCBBbWVyaWNhIE9w
# ZXJhdGlvbnMxJjAkBgNVBAsTHVRoYWxlcyBUU1MgRVNOOjNCQkQtRTMzOC1FOUEx
# MSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2aWNlMIICIjANBgkq
# hkiG9w0BAQEFAAOCAg8AMIICCgKCAgEA4BFoetAcSRbkfppRbhQrRt5kdlxzQnzz
# E13KdOmHsALUtW2xsyu4QwtSUTHrYXJoijP3m3QnBur+pOJUMi5Umh5h5CFAuaTR
# LZbrc6bFTfo6PjW3crvcNATIeCs33bi3cW3WtVc7Sg0l4xN3hJeTn/uYWN6R6CV/
# TYf+a+LXODb6rfbb1XGHiMaXIWfNQCt/lM6QPoXEeh0uu1wPPnEFAdXxskaFYdbA
# rtPqH3VQ3Fjhv7XEirSXIfnkQFQ3uyEZvOHz7D0xc9nSCUSQPz1GmUft8VuBXdWW
# yzWv8DG6t72mLSqIGkmYogslMVO5sKAN9osk3Bhwu4R/DIGVlThAbuwnzbzMq7Ef
# ELr7t5vdQ6rHOYGRzMb4HgDvSy4mmlPpJWJhVkLy16YpUtYg12//Nvk48BrcRJ3P
# MfxLy5JO1JI+LimeifMp5YD4T0ano3KCpR7CoMVpg98MxF1tWtPXdS9iKNNOMNNY
# t9UADAfxi4YJpjCBOWeFSNiZYfbF9p5MoeUDp2Ds5xApOM2vXCHTCj/rHXtp4b73
# Enaxl0PH1jv/jdZo09EiJF+NV2Y5vkDBkdN7Wut6X7I94NxOWta9KPWh4HLqYVtJ
# cK2wQP0xjKOcwvGeViPkcKa9DAIg2RsuYdvrjMf9vvxeGYsimril6ne6yJdbHgGE
# GMSkOEnpgdECAwEAAaOCATYwggEyMB0GA1UdDgQWBBTW3xCN4SrozJxeEYHb2suK
# 2RtV5DAfBgNVHSMEGDAWgBSfpxVdAF5iXYP05dJlpxtTNRnpcjBfBgNVHR8EWDBW
# MFSgUqBQhk5odHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NybC9NaWNy
# b3NvZnQlMjBUaW1lLVN0YW1wJTIwUENBJTIwMjAxMCgxKS5jcmwwbAYIKwYBBQUH
# AQEEYDBeMFwGCCsGAQUFBzAChlBodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtp
# b3BzL2NlcnRzL01pY3Jvc29mdCUyMFRpbWUtU3RhbXAlMjBQQ0ElMjAyMDEwKDEp
# LmNydDAMBgNVHRMBAf8EAjAAMBMGA1UdJQQMMAoGCCsGAQUFBwMIMA0GCSqGSIb3
# DQEBCwUAA4ICAQCGx3KcS7dodCzSd9+IgjWWLLWthGp7fSVHoqcHmxSMEDIo+0iE
# PN4ieGODi+WMJaacLxedegIXB3r2DEnGOjQF0gBoaecWLZBHJHleoDW3KdwuCN8q
# LVrw3fSkAoey3SIaYmAnXtEheDeSUWVB1yDHM7zYXvPnRLogp0tbFohj1BczSX7A
# HDbNWgZByLWksTNAFR4GX4CvEdooVZLYq8cGBtE/aNYdAZESdz37iRfpzo7dfnhW
# GIKvmzi0LP0nYGOA21FX67S3RINk20vrImcOHaszPrS3cnuVxsiZSgV+2iLOMX9R
# 4dcpjF9uGCZZvL8l/luMfMsrT5s4jR7bIcX+5SndT5u7fu1FM4vEAYW8tL2K3656
# FtSsLPs9+LqHNvg9lRcax9/cav/Cm3ngabi+fvgoqaGULHeUDuTYvNZwZcIv+9Sb
# GQxKJrKP5OCYqMr1QDNvNfAoJ7DSZzGWUsTOZMnkXWIfSG4xnT3XT1XL9JDyqzWp
# T7UTuIodBlZC/2uAXxAbVw3hFCLDOANNEHoQ/hEldyNFG1vm+DU5m0XI51RZObep
# 7ivxaBUHOTeF7nmADsNpjA4QKBRPtsbUx5NnsHfcRpGxQ5dm+rvxW4bFG+fl6D9D
# 3SdxUzT+hv+1a+LCDsWq+D6WOu+GkAojEssMLSFjqKkUvzj/60oxfRP8XzCCB3Ew
# ggVZoAMCAQICEzMAAAAVxedrngKbSZkAAAAAABUwDQYJKoZIhvcNAQELBQAwgYgx
# CzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRt
# b25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xMjAwBgNVBAMTKU1p
# Y3Jvc29mdCBSb290IENlcnRpZmljYXRlIEF1dGhvcml0eSAyMDEwMB4XDTIxMDkz
# MDE4MjIyNVoXDTMwMDkzMDE4MzIyNVowfDELMAkGA1UEBhMCVVMxEzARBgNVBAgT
# Cldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29m
# dCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENB
# IDIwMTAwggIiMA0GCSqGSIb3DQEBAQUAA4ICDwAwggIKAoICAQDk4aZM57RyIQt5
# osvXJHm9DtWC0/3unAcH0qlsTnXIyjVX9gF/bErg4r25PhdgM/9cT8dm95VTcVri
# fkpa/rg2Z4VGIwy1jRPPdzLAEBjoYH1qUoNEt6aORmsHFPPFdvWGUNzBRMhxXFEx
# N6AKOG6N7dcP2CZTfDlhAnrEqv1yaa8dq6z2Nr41JmTamDu6GnszrYBbfowQHJ1S
# /rboYiXcag/PXfT+jlPP1uyFVk3v3byNpOORj7I5LFGc6XBpDco2LXCOMcg1KL3j
# tIckw+DJj361VI/c+gVVmG1oO5pGve2krnopN6zL64NF50ZuyjLVwIYwXE8s4mKy
# zbnijYjklqwBSru+cakXW2dg3viSkR4dPf0gz3N9QZpGdc3EXzTdEonW/aUgfX78
# 2Z5F37ZyL9t9X4C626p+Nuw2TPYrbqgSUei/BQOj0XOmTTd0lBw0gg/wEPK3Rxjt
# p+iZfD9M269ewvPV2HM9Q07BMzlMjgK8QmguEOqEUUbi0b1qGFphAXPKZ6Je1yh2
# AuIzGHLXpyDwwvoSCtdjbwzJNmSLW6CmgyFdXzB0kZSU2LlQ+QuJYfM2BjUYhEfb
# 3BvR/bLUHMVr9lxSUV0S2yW6r1AFemzFER1y7435UsSFF5PAPBXbGjfHCBUYP3ir
# Rbb1Hode2o+eFnJpxq57t7c+auIurQIDAQABo4IB3TCCAdkwEgYJKwYBBAGCNxUB
# BAUCAwEAATAjBgkrBgEEAYI3FQIEFgQUKqdS/mTEmr6CkTxGNSnPEP8vBO4wHQYD
# VR0OBBYEFJ+nFV0AXmJdg/Tl0mWnG1M1GelyMFwGA1UdIARVMFMwUQYMKwYBBAGC
# N0yDfQEBMEEwPwYIKwYBBQUHAgEWM2h0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9w
# a2lvcHMvRG9jcy9SZXBvc2l0b3J5Lmh0bTATBgNVHSUEDDAKBggrBgEFBQcDCDAZ
# BgkrBgEEAYI3FAIEDB4KAFMAdQBiAEMAQTALBgNVHQ8EBAMCAYYwDwYDVR0TAQH/
# BAUwAwEB/zAfBgNVHSMEGDAWgBTV9lbLj+iiXGJo0T2UkFvXzpoYxDBWBgNVHR8E
# TzBNMEugSaBHhkVodHRwOi8vY3JsLm1pY3Jvc29mdC5jb20vcGtpL2NybC9wcm9k
# dWN0cy9NaWNSb29DZXJBdXRfMjAxMC0wNi0yMy5jcmwwWgYIKwYBBQUHAQEETjBM
# MEoGCCsGAQUFBzAChj5odHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpL2NlcnRz
# L01pY1Jvb0NlckF1dF8yMDEwLTA2LTIzLmNydDANBgkqhkiG9w0BAQsFAAOCAgEA
# nVV9/Cqt4SwfZwExJFvhnnJL/Klv6lwUtj5OR2R4sQaTlz0xM7U518JxNj/aZGx8
# 0HU5bbsPMeTCj/ts0aGUGCLu6WZnOlNN3Zi6th542DYunKmCVgADsAW+iehp4LoJ
# 7nvfam++Kctu2D9IdQHZGN5tggz1bSNU5HhTdSRXud2f8449xvNo32X2pFaq95W2
# KFUn0CS9QKC/GbYSEhFdPSfgQJY4rPf5KYnDvBewVIVCs/wMnosZiefwC2qBwoEZ
# QhlSdYo2wh3DYXMuLGt7bj8sCXgU6ZGyqVvfSaN0DLzskYDSPeZKPmY7T7uG+jIa
# 2Zb0j/aRAfbOxnT99kxybxCrdTDFNLB62FD+CljdQDzHVG2dY3RILLFORy3BFARx
# v2T5JL5zbcqOCb2zAVdJVGTZc9d/HltEAY5aGZFrDZ+kKNxnGSgkujhLmm77IVRr
# akURR6nxt67I6IleT53S0Ex2tVdUCbFpAUR+fKFhbHP+CrvsQWY9af3LwUFJfn6T
# vsv4O+S3Fb+0zj6lMVGEvL8CwYKiexcdFYmNcP7ntdAoGokLjzbaukz5m/8K6TT4
# JDVnK+ANuOaMmdbhIurwJ0I9JZTmdHRbatGePu1+oDEzfbzL6Xu/OHBE0ZDxyKs6
# ijoIYn/ZcGNTTY3ugm2lBRDBcQZqELQdVTNYs6FwZvKhggLMMIICNQIBATCB+KGB
# 0KSBzTCByjELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNV
# BAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjElMCMG
# A1UECxMcTWljcm9zb2Z0IEFtZXJpY2EgT3BlcmF0aW9uczEmMCQGA1UECxMdVGhh
# bGVzIFRTUyBFU046M0JCRC1FMzM4LUU5QTExJTAjBgNVBAMTHE1pY3Jvc29mdCBU
# aW1lLVN0YW1wIFNlcnZpY2WiIwoBATAHBgUrDgMCGgMVALfpQ0kV/dihcoo+9SZ9
# tAqEssrgoIGDMIGApH4wfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0
# b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3Jh
# dGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTAwDQYJ
# KoZIhvcNAQEFBQACBQDmvZL2MCIYDzIwMjIwOTAzMTY0NjQ2WhgPMjAyMjA5MDQx
# NjQ2NDZaMHUwOwYKKwYBBAGEWQoEATEtMCswCgIFAOa9kvYCAQAwBwIBAAICNAcw
# CAIBAAIDAMG1MAoCBQDmvuR2AgEAMDYGCisGAQQBhFkKBAIxKDAmMAwGCisGAQQB
# hFkKAwKgCjAIAgEAAgMHoSChCjAIAgEAAgMBhqAwDQYJKoZIhvcNAQEFBQADgYEA
# HVF5Cv3HnTHjdU+21Rac6yqUS9ChmMwCoFpp06jwWOTNHfBAkN4NMrzvmCActoK4
# 3rTRmviRqlN4poOShr3vNBsikNHIyUYdkMssNhHRAdqa9kBlBy5uTdiAdv9smENV
# w5pbYqmNUUbEOY9uOBE+lxFIL+32gqr8yOZOnLbUBqsxggQNMIIECQIBATCBkzB8
# MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVk
# bW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQDEx1N
# aWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMAITMwAAAZ3+ieX5e7tMwAABAAAB
# nTANBglghkgBZQMEAgEFAKCCAUowGgYJKoZIhvcNAQkDMQ0GCyqGSIb3DQEJEAEE
# MC8GCSqGSIb3DQEJBDEiBCD52FJReiFvKa0gd5XWiHVWsKRu4PfVDugKCpeEw1Hc
# RzCB+gYLKoZIhvcNAQkQAi8xgeowgecwgeQwgb0EIPUeY63giqBPgDSfgluVf9/M
# UvIS7g4EM5v6akyVh0WhMIGYMIGApH4wfDELMAkGA1UEBhMCVVMxEzARBgNVBAgT
# Cldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29m
# dCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENB
# IDIwMTACEzMAAAGd/onl+Xu7TMAAAQAAAZ0wIgQgXULJcs1pPpILjHpUZuPnufPG
# kEIbK2xUf+FvpIF3P2AwDQYJKoZIhvcNAQELBQAEggIAvODngPZWSl9XD++6hd24
# 1cYX0WKMKhKKsUdb+TI7kpggGbXH7B8TcT3OM65kbPpmABjnfk1MWHI6Iw2VILOl
# Igen8lww3iChR7x4+H913uos7YqfqGuscZTdidsYQqT68tYvaClmztjSXMEgb319
# vL1NL6na0LIv2l2PtVp+m9WtKvQD52vRLSnpS6H4epa7+9bxHcXbobTGsjq86E/e
# Q1tGxiczn2l/i/X1IEKM11AahmUyhO6zdP1tYn9bqATwqFTc9ZR34vu38V1768KN
# ixoFm0Cy1pqnD/ATpAGbW9EvaZeqShgYYkCvdmWoZfVpARgByhbP59M7WIuCSNgU
# 9BdLaaVfpnG/MoVwMz4EHTdibJE6OwnASKcDXJ78klZr/3gKY8SUB/2k0N4mQWvv
# /GmjZPqc9Af7X0dNL911OOWSMoP2BPoiqiX5JfsJTd/BaYLSGGDhe/HrYONHniBa
# 0VgxU46lfqaLhxYzkkmtLCejW1I6A/7yfpzUe6tKAIJym1Z4y/e/HNXhxdMSw+/4
# aTXuDl1VZ7XlA8d0a6lWbLEn4SfXxLrVpOZRXWSSRtd7zy3ZYWJdNpoBmddUlhUM
# 9mA5bPP+68PYkWC19nqhmRS9HDiL5+h4pAkKgWGdiy5fJN/UlLuAhEIPTSebD5jk
# 9SFCAr8c7mt4skUrFxyYGhM=
# SIG # End signature block
